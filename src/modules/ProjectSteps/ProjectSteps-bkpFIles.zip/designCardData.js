const designCardData = [
    {
        id: '01',
        label: 'Promoteam website design',
        image: require('../../assets/images/design1.png'),
        totalSales: '12 Sales',
    },
    {
        id: '02',
        label: 'Team website design',
        image: require('../../assets/images/design1.png'),
        totalSales: '10 Sales',
    },
    {
        id: '03',
        label: 'Proteam website design',
        image: require('../../assets/images/design1.png'),
        totalSales: '15 Sales',
    },
    {
        id: '04',
        label: 'Promoteam1 website design',
        image: require('../../assets/images/design1.png'),
        totalSales: '07 Sales',
    },
    {
        id: '05',
        label: 'Proteam2 website design',
        image: require('../../assets/images/design1.png'),
        totalSales: '18 Sales',
    },
    {
        id: '06',
        label: 'Team2 website design',
        image: require('../../assets/images/design1.png'),
        totalSales: '20 Sales',
    },
    {
        id: '07',
        label: 'Team3 website design',
        image: require('../../assets/images/design1.png'),
        totalSales: '09 Sales',
    },
];

export default designCardData;