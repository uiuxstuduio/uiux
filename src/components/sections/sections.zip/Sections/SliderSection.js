import React from 'react';
import { Link } from 'react-router-dom';
// Import Swiper React components
import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import 'swiper/css';
import 'swiper/css/free-mode';
import 'swiper/css/pagination';

// import required modules
import { FreeMode, Pagination } from 'swiper';

// TRENDING STYLE
import './treanding.scss';

// images
import square from '../../../assets/images/icon/arrow-down-square.svg';

const Treanding = ({ title, data }) => {
  return (
    <div className="treanding_wrapper">
      <div className="container">
        <div className="row">
          <div className="col-12">
            <div className="heading small">
              <h2>
                {title
                  .split('_')
                  .map((word) => word[0].toUpperCase() + word.slice(1))
                  .join(' ')}
              </h2>
            </div>
          </div>
        </div>
      </div>
      <Swiper
        slidesPerView={4}
        spaceBetween={30}
        freeMode={false}
        modules={[FreeMode, Pagination]}
        centeredSlides={true}
        loop={true}
        grabCursor={true}
        className="mySwiper treanding_slider"
        breakpoints={{
          0: {
            slidesPerView: 1,
            spaceBetween: 15,
            freeMode: false,
            centeredSlides: true,
            loop: true,
            grabCursor: true
          },
          768: {
            slidesPerView: 2,
            spaceBetween: 15,
            centeredSlides: true,
            loop: true,
            grabCursor: true
          },
          992: {
            slidesPerView: 3,
            spaceBetween: 15,
            centeredSlides: true,
            loop: true,
            grabCursor: true
          },
          1281: {
            slidesPerView: 4,
            spaceBetween: 24,
            centeredSlides: true,
            loop: true,
            grabCursor: true
          },
          2681: {
            slidesPerView: 6,
            spaceBetween: 50,
            centeredSlides: true,
            loop: true,
            grabCursor: true
          },
          3260: {
            slidesPerView: 8,
            spaceBetween: 50,
            centeredSlides: false,
            loop: true,
            grabCursor: true
          }
        }}
      >
        {data.map((item) => (
          <SwiperSlide key={item.id}>
            <Link to={`/product-details/${item.id}`}>
              <div className="images_wrapper">
                <img style={{ width: '100%' }} src={item.featured_image} alt="treanding-slide" />
              </div>
              <div className="text_wrapper">
                <div className="title">
                  <h2>{item.theme_name}</h2>
                  <span>
                    <img src={square} alt="Sale Icon" />
                    <label>{item.sale} sales</label>
                  </span>
                </div>
                <div className="btn_wrapper">
                  {item.theme_price ? `$${item.theme_price}` : 'Free'}
                </div>
              </div>
            </Link>
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
};

export default Treanding;
