import React from 'react';
import { Link } from 'react-router-dom';
import './topCategories.scss';

// Import Swiper React components
import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import 'swiper/css';
import 'swiper/css/free-mode';
import 'swiper/css/pagination';

// import required modules
import { FreeMode, Pagination } from 'swiper';

const TopCategories = ({ data }) => {
  return (
    <section className="topCategories_wrapper">
      <div className="container">
        <div className="row">
          <div className="col-12">
            <div className="heading small">
              <h2>Top Categories</h2>
            </div>
          </div>
          <div className="col-12">
            <div className="topCategories_block">
              <Swiper
                slidesPerView={3}
                spaceBetween={30}
                freeMode={false}
                modules={[FreeMode, Pagination]}
                loop={true}
                grabCursor={true}
                className="mySwiper categories_slider"
                breakpoints={{
                  0: {
                    slidesPerView: 1,
                    spaceBetween: 15,
                    freeMode: false
                  },
                  768: {
                    slidesPerView: 2,
                    spaceBetween: 15
                  },
                  992: {
                    slidesPerView: 3,
                    spaceBetween: 15
                  }
                }}
              >
                {data.map((item) => (
                  <SwiperSlide key={`category-${item.id}`}>
                    <Link to="/">
                      <div className="images_wrapper">
                        <img src={item.theme_category_image} alt="treanding-slide" />
                      </div>
                      <div className="text_wrapper">
                        <div className="title">
                          <h2>{item.categories_name}</h2>
                        </div>
                      </div>
                    </Link>
                  </SwiperSlide>
                ))}
              </Swiper>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TopCategories;
